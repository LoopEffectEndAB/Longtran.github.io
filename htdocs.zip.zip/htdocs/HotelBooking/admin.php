<?php
// admin_dashboard.php
session_start();
include 'db.php';

// Kiểm tra đăng nhập admin thực tế
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Access denied. Only admin can access this page.");
}

$bookings_sql = "
SELECT b.id, c.full_name, r.room_type, b.check_in, b.check_out, b.total_price, b.payment_status, b.status
FROM bookings b
JOIN customers c ON b.customer_id = c.id
JOIN rooms r ON b.room_id = r.id
ORDER BY b.id DESC
";
$bookings_result = $conn->query($bookings_sql);

// Truy vấn thanh toán
$payments_sql = "
SELECT p.id, p.booking_id, p.payment_method, p.payment_date, p.amount, p.status
FROM payments p
ORDER BY p.payment_date DESC
";
$payments_result = $conn->query($payments_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Hotel Booking</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6f8; margin: 0; }
        .admin-header {
            background: #2d3e50;
            color: #fff;
            padding: 24px 0 16px 0;
            text-align: center;
            font-size: 2.2rem;
            letter-spacing: 2px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .logout-btn {
            position: absolute;
            right: 32px;
            top: 32px;
            background: #dc3545;
            color: #fff;
            padding: 10px 22px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            font-size: 1rem;
            transition: background 0.2s;
        }
        .logout-btn:hover { background: #b52a37; }
        .container {
            max-width: 1100px;
            margin: 40px auto;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            padding: 36px 40px 40px 40px;
        }
        h2 { color: #007bff; margin-bottom: 18px; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 36px;
            background: #fff;
        }
        th, td {
            padding: 14px 16px;
            border-bottom: 1px solid #eee;
            text-align: center;
        }
        th {
            background: #007bff;
            color: #fff;
            font-size: 1.1rem;
        }
        tr:nth-child(even) { background: #f4f6f8; }
        .return-btn {
            background: #28a745;
            color: #fff;
            border: none;
            padding: 7px 18px;
            border-radius: 5px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s;
        }
        .return-btn:hover { background: #1e7e34; }
        .success-msg { color: #28a745; text-align: center; font-weight: bold; margin-bottom: 18px; }
    </style>
</head>
<body>
    <div class="admin-header">
        Admin Dashboard
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
    <div class="container">
        <?php
        // Xử lý thêm phòng
        if (isset($_POST['add_room'])) {
            $room_type = trim($_POST['room_type']);
            $room_number = trim($_POST['room_number']);
            $price = floatval($_POST['price']);
            $status = $_POST['status'];
            if ($room_type && $price > 0 && in_array($status, ['available','booked'])) {
                $stmt = $conn->prepare("INSERT INTO rooms (room_type, room_number, price, status) VALUES (?, ?, ?, ?)");
                $stmt->bind_param('ssds', $room_type, $room_number, $price, $status);
                if ($stmt->execute()) {
                    echo '<div class="success-msg">Room added successfully!</div>';
                } else {
                    echo '<div class="success-msg" style="color:red;">Failed to add room!</div>';
                }
                $stmt->close();
            }
        }
        // Xử lý chỉnh sửa phòng
        if (isset($_POST['edit_room_id'])) {
            $edit_id = intval($_POST['edit_room_id']);
            $edit_type = trim($_POST['edit_room_type']);
            $edit_room_number = trim($_POST['edit_room_number']);
            $edit_price = floatval($_POST['edit_price']);
            $edit_status = $_POST['edit_status'];
            if ($edit_type && $edit_price > 0 && in_array($edit_status, ['available','booked'])) {
                $stmt = $conn->prepare("UPDATE rooms SET room_type=?, room_number=?, price=?, status=? WHERE id=?");
                $stmt->bind_param('ssdsi', $edit_type, $edit_room_number, $edit_price, $edit_status, $edit_id);
                if ($stmt->execute()) {
                    echo '<div class="success-msg">Room updated successfully!</div>';
                } else {
                    echo '<div class="success-msg" style="color:red;">Failed to update room!</div>';
                }
                $stmt->close();
            }
        }
        // Xử lý trả phòng nếu admin bấm nút
        if (isset($_POST['return_room_id'])) {
            $booking_id = intval($_POST['return_room_id']);
            // Lấy room_id từ booking
            $result = $conn->query("SELECT room_id FROM bookings WHERE id = $booking_id");
            $room_id = 0;
            if ($row = $result->fetch_assoc()) {
                $room_id = $row['room_id'];
            }
            // Cập nhật trạng thái phòng và booking
            if ($room_id) {
                $conn->query("UPDATE rooms SET status = 'available' WHERE id = $room_id");
                $conn->query("UPDATE bookings SET status = 'completed' WHERE id = $booking_id");
                echo '<div class="success-msg">Room ID '.htmlspecialchars($room_id).' has been returned and booking marked as completed!</div>';
            } else {
                echo '<div class="success-msg" style="color:red;">Error: Room not found for this booking!</div>';
            }
        }
        ?>

        <h2>Room Management</h2>
        <!-- Add Room Form -->
        <form method="POST" style="margin-bottom:30px;display:flex;gap:18px;align-items:end;flex-wrap:wrap;">
            <div>
                <label>Room Type:</label>
                <input type="text" name="room_type" required style="padding:7px 12px;border-radius:5px;border:1px solid #ccc;">
            </div>
            <div>
                <label>Room Number:</label>
                <input type="text" name="room_number" required style="padding:7px 12px;border-radius:5px;border:1px solid #ccc;">
            </div>
            <div>
                <label>Price:</label>
                <input type="number" name="price" min="1" step="0.01" required style="padding:7px 12px;border-radius:5px;border:1px solid #ccc;">
            </div>
            <div>
                <label>Status:</label>
                <select name="status" style="padding:7px 12px;border-radius:5px;">
                    <option value="available">Available</option>
                    <option value="booked">Booked</option>
                </select>
            </div>
            <button type="submit" name="add_room" style="background:#007bff;color:#fff;padding:10px 24px;border-radius:6px;font-weight:bold;border:none;">Add Room</button>
        </form>

        <!-- Room List with Edit -->
        <table>
            <tr>
                <th>ID</th><th>Type</th><th>Number</th><th>Price</th><th>Status</th><th>Action</th>
            </tr>
            <?php
            $rooms = $conn->query("SELECT * FROM rooms ORDER BY id DESC");
            while($room = $rooms->fetch_assoc()): ?>
                <tr>
                    <form method="POST" style="display:contents;">
                    <td><?= $room['id'] ?></td>
                    <td><input type="text" name="edit_room_type" value="<?= htmlspecialchars($room['room_type']) ?>" style="width:110px;padding:5px 8px;border-radius:4px;border:1px solid #ccc;"></td>
                    <td><input type="text" name="edit_room_number" value="<?= htmlspecialchars($room['room_number']) ?>" style="width:110px;padding:5px 8px;border-radius:4px;border:1px solid #ccc;"></td>
                    <td><input type="number" name="edit_price" value="<?= $room['price'] ?>" min="1" step="0.01" style="width:90px;padding:5px 8px;border-radius:4px;border:1px solid #ccc;"></td>
                    <td>
                        <select name="edit_status" style="padding:5px 8px;border-radius:4px;">
                            <option value="available" <?= $room['status']==='available'?'selected':'' ?>>Available</option>
                            <option value="booked" <?= $room['status']==='booked'?'selected':'' ?>>Booked</option>
                        </select>
                    </td>
                    <td>
                        <button type="submit" name="edit_room_id" value="<?= $room['id'] ?>" class="return-btn" style="background:#ffc107;color:#222;">Save</button>
                    </td>
                    </form>
                </tr>
            <?php endwhile; ?>
        </table>

        <h2>All Bookings</h2>
        <form method="POST">
        <table>
            <tr>
                <th>ID</th><th>User</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Action</th>
            </tr>
            <?php
            // Reset pointer nếu vừa trả phòng
            $bookings_result->data_seek(0);
            while($row = $bookings_result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['full_name']) ?></td>
                    <td><?= $row['room_type'] ?></td>
                    <td><?= $row['check_in'] ?></td>
                    <td><?= $row['check_out'] ?></td>
                    <td>
                        <?php if ($row['status'] !== 'completed'): ?>
                            <button class="return-btn" type="submit" name="return_room_id" value="<?= $row['id'] ?>">Trả phòng</button>
                        <?php else: ?>
                            <span style="color:green;font-weight:bold;">Đã trả</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
        </form>

        <h2>Recent Payments</h2>
        <table>
            <tr>
                <th>ID</th><th>Booking ID</th><th>Method</th><th>Date</th><th>Amount</th><th>Status</th>
            </tr>
            <?php while($row = $payments_result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['booking_id'] ?></td>
                    <td><?= ucfirst($row['payment_method']) ?></td>
                    <td><?= $row['payment_date'] ?></td>
                    <td>$<?= number_format($row['amount'], 2) ?></td>
                    <td><?= $row['status'] ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>