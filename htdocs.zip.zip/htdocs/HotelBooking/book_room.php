<?php
session_start();
require_once 'db.php';
$room_types = ['Standard', 'Deluxe', 'Suite'];

// Lấy danh sách phòng còn trống theo loại phòng (dùng cho JS)
$available_rooms_by_type = [];
$sql = "SELECT id, room_type, room_number FROM rooms WHERE status = 'available'";
$res = $conn->query($sql);
while ($row = $res->fetch_assoc()) {
    $type = $row['room_type'];
    if (!isset($available_rooms_by_type[$type])) $available_rooms_by_type[$type] = [];
    $available_rooms_by_type[$type][] = [
        'id' => $row['id'],
        'room_number' => $row['room_number']
    ];
}
// Handle booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_room'])) {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
        echo '<div style="color:red;text-align:center;font-size:18px;margin-bottom:18px;">Bạn chưa có tài khoản, hãy đăng nhập để đặt phòng!</div>';
        echo '<div style="text-align:center;margin-bottom:24px;">';
        echo '<a href="login.php" style="background:#007bff;color:#fff;padding:10px 24px;border-radius:6px;text-decoration:none;font-weight:bold;margin-right:12px;">Login</a>';
        echo '<a href="index.php" style="background:#28a745;color:#fff;padding:10px 24px;border-radius:6px;text-decoration:none;font-weight:bold;">Home</a>';
        echo '</div>';
    } else {
        $room_type = $_POST['room_type'];
        $room_id = isset($_POST['room_id']) ? intval($_POST['room_id']) : 0;
        $check_in = $_POST['check_in'];
        $check_out = $_POST['check_out'];
        // Kiểm tra phòng còn trống không
        $stmt = $conn->prepare('SELECT id FROM rooms WHERE id = ? AND room_type = ? AND status = "available"');
        $stmt->bind_param('is', $room_id, $room_type);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->close();
            $stmt = $conn->prepare('UPDATE rooms SET status = "booked" WHERE id = ?');
            $stmt->bind_param('i', $room_id);
            $stmt->execute();
            $_SESSION['booked_room_id'] = $room_id;
            header('Location: payment.php');
            exit();
        } else {
            echo '<div style="color:red;text-align:center;">Phòng này đã được đặt hoặc không tồn tại. Vui lòng chọn lại.</div>';
        }
    }
}
// Handle return room (customer or admin)
if (isset($_POST['return_room']) && isset($_POST['room_id'])) {
    $room_id = $_POST['room_id'];
    // Chỉ cho admin trả phòng
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        $stmt = $conn->prepare('UPDATE rooms SET status = "available" WHERE id = ?');
        $stmt->bind_param('i', $room_id);
        $stmt->execute();
        // Reload lại trang để cập nhật danh sách phòng
        $_SESSION['return_success'] = true;
        header('Location: book_room.php');
        exit();
    } else {
        echo '<div style="color:red;text-align:center;">You do not have permission to return this room.</div>';
    }
}
// Show all rooms and booking form
echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '<title>Book a Room</title>';
echo '<style>';
echo 'body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 0; }';
echo '.container { max-width: 600px; margin: 40px auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); padding: 32px; }';
echo 'h2 { text-align: center; margin-bottom: 28px; color: #2d3e50; }';
echo 'table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }';
echo 'th, td { padding: 12px 10px; border-bottom: 1px solid #eee; text-align: center; }';
echo 'th { background: #007bff; color: #fff; font-size: 16px; }';
echo 'tr:nth-child(even) { background: #f4f6f8; }';
echo '.status-available { color: green; font-weight: bold; }';
echo '.status-booked { color: red; font-weight: bold; }';
echo 'label { display: block; margin-bottom: 8px; font-weight: bold; color: #2d3e50; }';
echo 'select, input[type="date"] { width: 100%; padding: 10px; margin-bottom: 18px; border: 1px solid #ccc; border-radius: 6px; }';
echo 'button { background: #007bff; color: #fff; border: none; padding: 10px 24px; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer; margin: 5px; }';
echo 'button:hover { background: #0056b3; }';
echo '.home-btn { display: block; margin: 0 auto 20px auto; background: #28a745; }';
echo '</style>';
echo '</head>';
echo '<body>';
echo '<div class="container">';
// Hiển thị thông báo trả phòng thành công nếu có
if (isset($_SESSION['return_success']) && $_SESSION['return_success']) {
    echo '<div style="color:green;text-align:center;">Room returned successfully!</div>';
    unset($_SESSION['return_success']);
}
echo '<a href="index.php" class="home-btn"><button class="home-btn">Home</button></a>';
echo '<h2>Room List & Booking</h2>';
// Show all rooms
$result = $conn->query('SELECT * FROM rooms');
echo '<table>';
echo '<tr><th>ID</th><th>Type</th><th>Status</th><th>Customer</th><th>Action</th></tr>';
while ($row = $result->fetch_assoc()) {
    $status_class = $row['status'] === 'available' ? 'status-available' : 'status-booked';
    echo '<tr>';
    echo '<td>'.$row['id'].'</td>';
    echo '<td>'.$row['room_type'].'</td>';
    echo '<td class="'.$status_class.'">'.ucfirst($row['status']).'</td>';
    echo '<td>-</td>'; // Không còn cột customer_username trong bảng rooms
    // Return room button (only for admin)
    if ($row['status'] === 'booked' && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        echo '<td><form method="POST" style="display:inline;"><input type="hidden" name="room_id" value="'.$row['id'].'"><button type="submit" name="return_room">Return Room</button></form></td>';
    } else {
        echo '<td>-</td>';
    }
    echo '</tr>';
}
echo '</table>';
// Booking form: luôn hiển thị cho mọi người
echo '<h3>Book a Room</h3>';
echo '<form method="POST" action="book_room.php" id="bookingForm">';
echo '<label>Room Type:</label> <select name="room_type" id="room_type_select" required onchange="updateRoomNumbers()">';
foreach ($room_types as $type) {
    echo '<option value="'.$type.'">'.$type.'</option>';
}
echo '</select>';
echo '<label>Room Number:</label> <select name="room_id" id="room_number_select" required></select>';
echo '<label>Check-in Date:</label> <input type="date" name="check_in" required>';
echo '<label>Check-out Date:</label> <input type="date" name="check_out" required>';
echo '<button type="submit" name="book_room">Book Room</button>';
echo '</form>';

// Truyền dữ liệu phòng còn trống sang JS
echo '<script>';
echo 'const availableRooms = '.json_encode($available_rooms_by_type).';';
echo 'function updateRoomNumbers() {';
echo '  var type = document.getElementById("room_type_select").value;';
echo '  var roomSelect = document.getElementById("room_number_select");';
echo '  roomSelect.innerHTML = "";';
echo '  if (availableRooms[type]) {';
echo '    availableRooms[type].forEach(function(room) {';
echo '      var opt = document.createElement("option");';
echo '      opt.value = room.id;';
echo '      opt.text = room.room_number;';
echo '      roomSelect.appendChild(opt);';
echo '    });';
echo '  } else {';
echo '    var opt = document.createElement("option");';
echo '    opt.value = "";';
echo '    opt.text = "No available room";';
echo '    roomSelect.appendChild(opt);';
echo '  }';
echo '}';
echo 'document.addEventListener("DOMContentLoaded", function() { updateRoomNumbers(); });';
echo '</script>';
echo '</div>';
echo '</body>';
echo '</html>';
?>