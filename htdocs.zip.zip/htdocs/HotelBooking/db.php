<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "hotelbooking2";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Set charset to utf8 for Vietnamese and special characters
$conn->set_charset("utf8");
?>
