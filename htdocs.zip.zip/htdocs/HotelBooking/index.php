<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ABC Hotel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
            padding: 0;
        }
        header {
            background: #2d3e50;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        nav {
            background: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            display: flex;
            justify-content: center;
            gap: 30px;
            padding: 15px 0;
        }
        nav a {
            color: #2d3e50;
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
            transition: color 0.2s;
        }
        nav a:hover {
            color: #007bff;
        }
        .banner {
            background: url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80') center/cover no-repeat;
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 2.5rem;
            font-weight: bold;
            text-shadow: 2px 2px 8px rgba(0,0,0,0.3);
        }
        .main {
            max-width: 900px;
            margin: 40px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            padding: 30px;
            text-align: center;
        }
        .main h2 {
            margin-bottom: 20px;
        }
        .btn-group {
            display: flex;
            justify-content: center;
            gap: 25px;
            margin-top: 30px;
        }
        .btn {
            background: #007bff;
            color: #fff;
            border: none;
            padding: 15px 35px;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.2s;
            text-decoration: none;
        }
        .btn:hover {
            background: #0056b3;
        }
        footer {
            background: #2d3e50;
            color: #fff;
            text-align: center;
            padding: 15px 0;
            position: fixed;
            left: 0;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>ABC Hotel</h1>
        <p>Welcome to the hotel management system</p>
    </header>
    <nav>
        <a href="book_room.php">Book Room</a>
        <a href="payment.php">Payment</a>
        <a href="report.php">Report</a>
        <?php if (isset($_SESSION['username'])): ?>
            <a href="logout.php" style="color:red;">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </nav>
    <div class="banner">
        Experience excellent service at ABC Hotel
    </div>
    <div class="main">
        <?php
        session_start();
        if (isset($_SESSION['username'])) {
            echo '<h2>Welcome, <span style="color:#007bff">'.htmlspecialchars($_SESSION['username']).'</span>! (' . $_SESSION['role'] . ')</h2>';
        } else {
            echo '<h2>Welcome to ABC Hotel!</h2>';
        }
        ?>
        <div class="btn-group">
            <a class="btn" href="book_room.php">Book Room</a>
            <a class="btn" href="payment.php">Payment</a>
            <a class="btn" href="report.php">View Report</a>
            <?php if (isset($_SESSION['username'])): ?>
                <a class="btn" href="logout.php" style="background:#dc3545;">Logout</a>
            <?php else: ?>
                <a class="btn" href="login.php">Login</a>
                <a class="btn" href="register.php">Register</a>
            <?php endif; ?>
        </div>
    </div>
    <footer>
        &copy; 2025 ABC Hotel. All rights reserved.
    </footer>

    <style>
    .room-gallery {
        display: flex;
        justify-content: center;
        gap: 32px;
        margin: 40px 0 60px 0;
        flex-wrap: wrap;
    }
    .room-card {
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        width: 270px;
        text-align: center;
        padding: 18px 18px 28px 18px;
        transition: box-shadow 0.2s;
    }
    .room-card:hover {
        box-shadow: 0 4px 16px rgba(0,0,0,0.13);
    }
    .room-card img {
        width: 100%;
        height: 170px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 16px;
    }
    .room-card h3 {
        margin: 0 0 10px 0;
        color: #007bff;
    }
    .room-card p {
        color: #444;
        font-size: 15px;
        margin-bottom: 0;
    }
    </style>

    <div class="room-gallery">
        <div class="room-card">
            <img src="img/standard.jpg" alt="Standard Room" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80';">
            <h3>Standard Room</h3>
            <p>Phòng tiêu chuẩn với đầy đủ tiện nghi cơ bản, phù hợp cho cá nhân hoặc cặp đôi.</p>
        </div>
        <div class="room-card">
            <img src="../img/deluxe.jpg" alt="Deluxe Room" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=400&q=80';">
            <h3>Deluxe Room</h3>
            <p>Phòng Deluxe rộng rãi, nội thất sang trọng, view đẹp, thích hợp cho gia đình nhỏ.</p>
        </div>
        <div class="room-card">
            <img src="img/suite.jpg" alt="Suite Room" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=crop&w=400&q=80';">
            <h3>Suite Room</h3>
            <p>Phòng Suite cao cấp, không gian riêng tư, tiện nghi hiện đại, lý tưởng cho kỳ nghỉ sang trọng.</p>
        </div>
    </div>
</body>
</html>