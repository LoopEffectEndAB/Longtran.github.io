-- Thêm tài khoản admin ảo
INSERT INTO admins (username, password, full_name, email) VALUES
('tranlong', '$2y$10$exampleadminhash', 'Trần Long', 'tranlong@example.com');

-- Thêm 2 tài khoản khách ảo
INSERT INTO customers (username, password, full_name, email, phone) VALUES
('khach1', '$2y$10$examplecus1hash', 'Nguyễn Văn A', 'khach1@example.com', '0900000001'),
('khach2', '$2y$10$examplecus2hash', 'Lê Thị B', 'khach2@example.com', '0900000002');
