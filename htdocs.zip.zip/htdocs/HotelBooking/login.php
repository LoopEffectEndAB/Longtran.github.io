
<?php
session_start();
require_once 'db.php';
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    // Check admin table
    $stmt = $conn->prepare('SELECT admin_id, password FROM admins WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = 'admin';
            $_SESSION['user_id'] = $id;
            header('Location: admin.php');
            exit();
        }
    }
    $stmt->close();
    // Check customers table
    $stmt = $conn->prepare('SELECT id, username, password, full_name, email, phone FROM customers WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $username_db, $hashed_password, $full_name, $email, $phone);
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['username'] = $username_db;
            $_SESSION['role'] = 'customer';
            $_SESSION['user_id'] = $id;
            $_SESSION['full_name'] = $full_name;
            header('Location: index.php');
            exit();
        }
    }
    $stmt->close();
    $login_error = 'Invalid username or password.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ABC Hotel</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f8; }
        .container { max-width: 400px; margin: 80px auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); padding: 30px; }
        h2 { text-align: center; margin-bottom: 25px; }
        input[type="text"], input[type="password"] { width: 100%; padding: 12px; margin: 10px 0 20px 0; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; background: #007bff; color: #fff; border: none; padding: 12px; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer; }
        button:hover { background: #0056b3; }
        .register-link { text-align: center; margin-top: 15px; }
        .login-status { position: fixed; top: 10px; left: 10px; z-index: 999; background: #fff; padding: 8px 16px; border-radius: 6px; box-shadow: 0 2px 8px #0001; font-size: 15px; }
    </style>
</head>
<body>
    <?php if (isset($_SESSION['username'])): ?>
        <div class="login-status">
            Đã đăng nhập: <b><?= htmlspecialchars($_SESSION['username']) ?></b> (<?= $_SESSION['role'] ?>)
        </div>
    <?php endif; ?>
    <div class="container">
        <h2>Login</h2>
        <?php if ($login_error): ?>
            <div style="color:red;text-align:center; margin-bottom:10px;"> <?= htmlspecialchars($login_error) ?> </div>
        <?php endif; ?>
        <form method="POST" action="login.php">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <div class="register-link">
            <a href="register.php">Don't have an account? Register</a>
        </div>
    </div>
</body>
</html>

