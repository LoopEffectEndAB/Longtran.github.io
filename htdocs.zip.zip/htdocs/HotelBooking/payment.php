<?php
session_start();
require_once 'db.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Access Denied</title><style>body{font-family:Arial,sans-serif;text-align:center;margin-top:80px;color:#d9534f;}</style></head><body><h2>Access Denied</h2><p>You must login as a customer to view your payments.</p></body></html>';
    exit();
}

echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '<title>Payment</title>';
echo '<style>';
echo 'body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 0; }';
echo '.container { max-width: 600px; margin: 40px auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); padding: 32px; }';
echo 'h2 { text-align: center; margin-bottom: 28px; color: #2d3e50; }';
echo 'table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }';
echo 'th, td { padding: 12px 10px; border-bottom: 1px solid #eee; text-align: center; }';
echo 'th { background: #007bff; color: #fff; font-size: 16px; }';
echo 'tr:nth-child(even) { background: #f4f6f8; }';
echo '.success { color: green; text-align: center; margin-bottom: 20px; }';
echo '.error { color: red; text-align: center; margin-bottom: 20px; }';
echo '</style>';
echo '</head>';
echo '<body>';
echo '<div class="container">';

// Nếu vừa đặt phòng, hiển thị thông tin phòng và form thanh toán
if (isset($_SESSION['booked_room_id'])) {
    $room_id = $_SESSION['booked_room_id'];
    // Lấy thông tin phòng
    $stmt = $conn->prepare('SELECT room_type, price FROM rooms WHERE id = ?');
    $stmt->bind_param('i', $room_id);
    $stmt->execute();
    $stmt->bind_result($room_type, $price);
    $stmt->fetch();
    $stmt->close();

    // Hiển thị form thanh toán
    echo '<h2>Payment for Room</h2>';
    echo '<table style="margin-bottom:20px;">';
    echo '<tr><th>Room ID</th><th>Type</th><th>Price</th></tr>';
    echo '<tr><td>'.$room_id.'</td><td>'.$room_type.'</td><td>'.number_format($price).' VND</td></tr>';
    echo '</table>';
    echo '<form method="POST" action="payment.php">';
    echo '<label for="payment_method">Select Payment Method:</label>';
    echo '<select name="payment_method" id="payment_method" required>';
    echo '<option value="credit_card">Credit Card</option>';
    echo '<option value="e_wallet">E-Wallet</option>';
    echo '<option value="bank_transfer">Bank Transfer</option>';
    echo '</select>';
    echo '<input type="hidden" name="room_id" value="'.$room_id.'">';
    echo '<input type="hidden" name="amount" value="'.$price.'">';
    echo '<button type="submit" name="pay" style="margin-top:15px;">Pay Now</button>';
    echo '</form>';

    // Xử lý thanh toán
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay'])) {
        $payment_method = $_POST['payment_method'];
        $amount = $_POST['amount'];
        // Tạo booking mới
        $stmt = $conn->prepare('INSERT INTO bookings (customer_id, room_id, check_in, check_out, status) VALUES (?, ?, CURDATE(), CURDATE(), "confirmed")');
        $stmt->bind_param('ii', $_SESSION['user_id'], $room_id);
        $stmt->execute();
        $booking_id = $stmt->insert_id;
        $stmt->close();
        // Tạo payment mới
        $stmt = $conn->prepare('INSERT INTO payments (booking_id, amount, payment_method, status) VALUES (?, ?, ?, "paid")');
        $stmt->bind_param('ids', $booking_id, $amount, $payment_method);
        $stmt->execute();
        $stmt->close();
        // Xóa session booked_room_id
        unset($_SESSION['booked_room_id']);
        echo '<div class="success">Payment successful! Thank you for your booking.</div>';
    }
    echo '<a href="index.php">Back to Home</a>';
    echo '</div></body></html>';
    exit();
}

// Nếu không vừa đặt phòng, hiển thị lịch sử thanh toán
echo '<h2>My Payments</h2>';
$result = $conn->prepare('SELECT p.id, r.room_type, p.amount, p.payment_method, p.payment_date 
FROM payments p 
JOIN bookings b ON p.id = b.id 
JOIN rooms r ON b.id = r.id 
WHERE b.id = ? 
ORDER BY p.payment_date DESC');
$result->bind_param('i', $_SESSION['user_id']);
$result->execute();
$result->store_result();
$result->bind_result($id, $room_type, $amount, $method, $payment_date);
echo '<table>';
echo '<tr><th>ID</th><th>Room Type</th><th>Amount</th><th>Method</th><th>Date</th></tr>';
while ($result->fetch()) {
    echo '<tr>';
    echo '<td>'.$id.'</td>';
    echo '<td>'.$room_type.'</td>';
    echo '<td>'.number_format($amount).' VND</td>';
    echo '<td>'.$method.'</td>';
    echo '<td>'.$payment_date.'</td>';
    echo '</tr>';
}
echo '</table>';
echo '<a href="index.php">Back to Home</a>';
echo '</div>';
echo '</body>';
echo '</html>';
$result->close();
?>