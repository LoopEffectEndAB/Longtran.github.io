<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - ABC Hotel</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f8; }
        .container { max-width: 400px; margin: 80px auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); padding: 30px; }
        h2 { text-align: center; margin-bottom: 25px; }
        input[type="text"], input[type="password"], input[type="email"] { width: 100%; padding: 12px; margin: 10px 0 20px 0; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; background: #007bff; color: #fff; border: none; padding: 12px; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer; }
        button:hover { background: #0056b3; }
        .login-link { text-align: center; margin-top: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <form method="POST" action="register.php">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="phone" placeholder="Phone Number" required>
            <button type="submit">Register</button>
        </form>
        <div class="login-link">
            <a href="login.php">Already have an account? Login</a>
        </div>
    </div>
</body>
</html>
<?php
require_once 'db.php'; // Đảm bảo db.php kết nối tới database
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);   
    // Kiểm tra tất cả các trường đều được nhập
    if ($username && $password && $full_name && $email && $phone) {
        // Kiểm tra username đã tồn tại chưa
    $stmt = $conn->prepare('SELECT id FROM customers WHERE username = ?');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            echo '<div style="color:red;text-align:center;">Tên đăng nhập đã tồn tại.</div>';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('INSERT INTO customers (username, password, full_name, email, phone) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('sssss', $username, $hashed_password, $full_name, $email, $phone);
            if ($stmt->execute()) {
                echo '<div style="color:green;text-align:center;">Đăng ký thành công! Vui lòng đăng nhập.</div>';
                header('Refresh:2; url=login.php');
                exit();
            } else {
                echo '<div style="color:red;text-align:center;">Đăng ký thất bại. Vui lòng thử lại.</div>';
            }
        }
        $stmt->close();
    } else {
        echo '<div style="color:red;text-align:center;">Vui lòng nhập đầy đủ thông tin.</div>';
    }
}
?>
