<?php
session_start();
require_once 'db.php';
// Chỉ admin mới xem được báo cáo
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Access Denied</title><style>body{font-family:Arial,sans-serif;text-align:center;margin-top:80px;color:#d9534f;}</style></head><body><h2>Access Denied</h2><p>You do not have permission to view this page.</p></body></html>';
    exit();
}
// Lấy danh sách các thanh toán
$result = $conn->query('SELECT p.id, r.room_type, p.amount, p.payment_method, p.payment_date, b.customer_id FROM payments p JOIN bookings b ON p.booking_id = b.id JOIN rooms r ON b.room_id = r.id ORDER BY p.payment_date DESC');
echo '<!DOCTYPE html>';
echo '<html lang="en">';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '<title>Payment Report</title>';
echo '<style>';
echo 'body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 0; }';
echo '.container { max-width: 900px; margin: 40px auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); padding: 32px; }';
echo 'h2 { text-align: center; margin-bottom: 28px; color: #2d3e50; }';
echo 'table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }';
echo 'th, td { padding: 12px 10px; border-bottom: 1px solid #eee; text-align: center; }';
echo 'th { background: #007bff; color: #fff; font-size: 16px; }';
echo 'tr:nth-child(even) { background: #f4f6f8; }';
echo '</style>';
echo '</head>';
echo '<body>';
echo '<div class="container">';
echo '<h2>Payment Report</h2>';
echo '<table>';
echo '<tr><th>ID</th><th>Room Type</th><th>Customer</th><th>Amount</th><th>Method</th><th>Date</th></tr>';
while ($row = $result->fetch_assoc()) {
    echo '<tr>';
    echo '<td>'.$row['id'].'</td>';
    echo '<td>'.$row['room_type'].'</td>';
    echo '<td>'.$row['customer_username'].'</td>';
    echo '<td>'.number_format($row['amount']).' VND</td>';
    echo '<td>'.$row['payment_method'].'</td>';
    echo '<td>'.$row['payment_date'].'</td>';
    echo '</tr>';
}
echo '</table>';
echo '</div>';
echo '</body>';
echo '</html>';
?>