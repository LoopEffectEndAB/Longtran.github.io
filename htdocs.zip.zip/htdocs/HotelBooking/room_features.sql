-- Table for room features
CREATE TABLE room_features (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    feature VARCHAR(100) NOT NULL,
    FOREIGN KEY (room_id) REFERENCES rooms(id)
);
