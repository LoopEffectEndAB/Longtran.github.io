<?php
session_start();
require_once 'db.php';
// Only admin can view all rooms
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    echo '<!DOCTYPE html>';
    echo '<html lang="en">';
    echo '<head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>Room Management</title>';
    echo '<style>';
    echo 'body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 0; }';
    echo 'h2 { text-align: center; margin-top: 30px; color: #2d3e50; }';
    echo 'table { margin: 30px auto; border-collapse: collapse; width: 80%; background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }';
    echo 'th, td { padding: 14px 18px; border-bottom: 1px solid #eee; text-align: center; }';
    echo 'th { background: #007bff; color: #fff; font-size: 18px; }';
    echo 'tr:nth-child(even) { background: #f4f6f8; }';
    echo '.status-available { color: green; font-weight: bold; }';
    echo '.status-booked { color: red; font-weight: bold; }';
    echo '</style>';
    echo '</head>';
    echo '<body>';
    echo '<h2>Room Management</h2>';
    echo '<table>';
    echo '<tr><th>ID</th><th>Type</th><th>Status</th><th>Customer</th></tr>';
    $result = $conn->query("SELECT * FROM rooms WHERE room_type IN ('Standard', 'Dulexu', 'Suite')");
    while ($row = $result->fetch_assoc()) {
        $status_class = $row['status'] === 'available' ? 'status-available' : 'status-booked';
        echo '<tr>';
    echo '<td>'.$row['id'].'</td>';
    echo '<td>'.$row['room_type'].'</td>';
        echo '<td class="'.$status_class.'">'.ucfirst($row['status']).'</td>';
        echo '<td>-</td>';
        echo '</tr>';
    }
    echo '</table>';
    echo '</body>';
    echo '</html>';
} else {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Access Denied</title><style>body{font-family:Arial,sans-serif;text-align:center;margin-top:80px;color:#d9534f;}</style></head><body><h2>Access Denied</h2><p>You do not have permission to view this page.</p></body></html>';
}
?>
